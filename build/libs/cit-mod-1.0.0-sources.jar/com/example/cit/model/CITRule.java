package com.example.cit.model;

import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_6880;
import net.minecraft.class_9304;
import net.minecraft.class_9334;

public record CITRule(
    String packPath,
    List<class_1792> items,
    class_2960 replacementModel,
    Map<class_2960, class_2960> textures,
    Map<String, Pattern> componentPatterns,
    Pattern displayNamePattern,
    IntRange damageRange,
    IntRange stackSizeRange,
    Map<class_2960, IntRange> enchantmentLevels,
    int weight
) {
    public boolean matches(class_1799 stack) {
        if (items != null && !items.isEmpty() && !items.contains(stack.method_7909())) {
            return false;
        }

        if (displayNamePattern != null) {
            class_2561 customName = stack.method_57824(class_9334.field_49631);
            String name = (customName != null) ? customName.getString() : stack.method_7964().getString();
            if (!displayNamePattern.matcher(name).matches()) {
                return false;
            }
        }

        if (damageRange != null) {
            int damage = stack.method_7919();
            if (!damageRange.contains(damage)) return false;
        }

        if (stackSizeRange != null) {
            if (!stackSizeRange.contains(stack.method_7947())) return false;
        }

        if (enchantmentLevels != null && !enchantmentLevels.isEmpty()) {
            class_9304 enchantments = stack.method_57824(class_9334.field_49633);
            if (enchantments == null) return false;
            
            for (Map.Entry<class_2960, IntRange> entry : enchantmentLevels.entrySet()) {
                boolean found = false;
                for (class_6880<class_1887> ench : enchantments.method_57534()) {
                    if (ench.method_40230().isPresent() && ench.method_40230().get().method_29177().equals(entry.getKey())) {
                        if (entry.getValue().contains(enchantments.method_57536(ench))) {
                            found = true;
                            break;
                        }
                    }
                }
                if (!found) return false;
            }
        }

        return true;
    }

    public record IntRange(int min, int max) {
        public boolean contains(int value) {
            return value >= min && value <= max;
        }
    }
}
